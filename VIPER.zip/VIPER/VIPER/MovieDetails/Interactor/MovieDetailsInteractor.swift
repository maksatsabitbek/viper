//
//  MovieDetailsMovieDetailsInteractor.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import Foundation

class MovieDetailsInteractor {

    weak var output: MovieDetailsInteractorOutput!

}

// MARK: MovieDetailsInteractorInput
extension MovieDetailsInteractor: MovieDetailsInteractorInput {
  
    
    

    
    func fetchMovieDetails(with id: Int) {
        var urlComponents = URLComponents(string: "https://api.themoviedb.org/3/movie/\(id)")
        urlComponents?.queryItems = [
            URLQueryItem(name: "api_key", value: "9f542800573798d83ae44064cdf3f384")
        ]
        
        if let url = urlComponents?.url?.absoluteURL {
            URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                if error == nil {
                    guard let data = data else {return}
                    DispatchQueue.global().async {
                        do {
                            let movieDetails = try JSONDecoder().decode(MovieDetailsEntity.self, from: data)
                            DispatchQueue.main.async {
                                self?.output.setMovieDetails(movieDetails)
                            }
                        } catch {
                            print(error)
                        }
                    }
                }
            }.resume()
        }
    }
}

