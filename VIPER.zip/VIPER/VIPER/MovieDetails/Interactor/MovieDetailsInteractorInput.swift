//
//  MovieDetailsMovieDetailsInteractorInput.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import Foundation

protocol MovieDetailsInteractorInput {
    func fetchMovieDetails(with id: Int)
    func fetchMovieCasts(with id: Int)
}
