//
//  MovieDetailsMovieDetailsViewController.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit
import Kingfisher

class MovieDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var releaseDate: UILabel!
    @IBOutlet weak var descriptionlabel: UILabel!

    
    var output: MovieDetailsViewOutput!
    private var movie: MovieDetailsEntity? {
        didSet{
            if let movie = movie {
                title = movie.title
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                titleLabel.text = movie.title
                releaseDate.text = movie.releaseDate
                descriptionlabel.text = movie.description
            }
        }
    }
}

    






