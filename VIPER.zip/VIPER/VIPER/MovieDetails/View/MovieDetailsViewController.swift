//
//  MovieDetailsMovieDetailsViewController.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit
import Kingfisher

class MovieDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var releaseDate: UILabel!
    @IBOutlet weak var descriptionlabel: UILabel!
    @IBOutlet weak var castsCollectionView: UICollectionView!
    
    var output: MovieDetailsViewOutput!
    private var movie: MovieDetailsEntity? {
        didSet{
            if let movie = movie {
                title = movie.title
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                titleLabel.text = movie.title
                releaseDate.text = movie.releaseDate
                descriptionlabel.text = movie.description
            }
        }
    }
    
    private var movieCasts: [CastsEntity.Cast] = [CastsEntity.Cast]() {
        didSet {
            castsCollectionView.reloadData()
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        output.viewIsReady()
        configureCollectionView()
    }
    
}

// MARK: MovieDetailsViewInput
extension MovieDetailsViewController: MovieDetailsViewInput {
    func setMovieCasts(_ casts: [CastsEntity.Cast]) {
        movieCasts = casts
    }
    
    func setMovieDetails(_ movieDetails: MovieDetailsEntity) {
        movie = movieDetails
    }
    

    func setupInitialState() {
        
    }
}

// MARK: Privte func
private extension MovieDetailsViewController {
    func configureCollectionView(){
        castsCollectionView.dataSource = self
        castsCollectionView.delegate = self
        castsCollectionView.register(CastCollectionViewCell.nib, forCellWithReuseIdentifier: CastCollectionViewCell.identifier)
    }
}

// MARK: UICollectionViewDelegate
extension MovieDetailsViewController: UICollectionViewDelegate {
    
}

// MARK: UICollectionViewDataSource
extension MovieDetailsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movieCasts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = castsCollectionView.dequeueReusableCell(withReuseIdentifier: CastCollectionViewCell.identifier, for: indexPath) as! CastCollectionViewCell
        cell.setCast(movieCasts[indexPath.item])
        return cell
    }
}


