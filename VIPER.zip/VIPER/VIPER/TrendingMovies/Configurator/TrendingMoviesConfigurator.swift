//
//  TrendingMoviesTrendingMoviesConfigurator.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit
import Foundation

class TrendingMoviesModuleConfigurator {

    func configureModuleForViewInput<UIViewController>(viewInput: UIViewController, collection: MovieCollection) {

        if let viewController = viewInput as? TrendingMoviesViewController {
            configure(viewController: viewController, collection: collection)
        }
    }

    private func configure(viewController: TrendingMoviesViewController, collection: MovieCollection) {

        let router = TrendingMoviesRouter()

        let presenter = TrendingMoviesPresenter(colection: collection)
        presenter.view = viewController
        presenter.router = router

        let interactor = TrendingMoviesInteractor()
        interactor.output = presenter

        presenter.interactor = interactor
        viewController.output = presenter
    }
}
