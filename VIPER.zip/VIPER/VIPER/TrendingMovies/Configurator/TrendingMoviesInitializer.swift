//
//  TrendingMoviesTrendingMoviesInitializer.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit

class TrendingMoviesModuleInitializer: NSObject {

    //Connect with object on storyboard
//    @IBOutlet weak var trendingmoviesViewController: TrendingMoviesViewController!

//    override func awakeFromNib() {
//
//        let configurator = TrendingMoviesModuleConfigurator()
//        configurator.configureModuleForViewInput(viewInput: trendingmoviesViewController)
//    }
    
    func viewController() -> UIViewController {
        let storyboard = UIStoryboard(name: "TrendingMoviesStoryboard", bundle: Bundle.main)
        let vc: TrendingMoviesViewController = storyboard.instantiateViewController(withIdentifier: "TrendingMoviesViewController") as! TrendingMoviesViewController
        let configurator = TrendingMoviesModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: vc)
        return vc
    }

}
