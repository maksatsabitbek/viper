//
//  TrendingMoviesTrendingMoviesInitializer.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit

class TrendingMoviesModuleInitializer: NSObject {

    //Connect with object on storyboard
//    @IBOutlet weak var trendingmoviesViewController: TrendingMoviesViewController!

//    override func awakeFromNib() {
//
//        let configurator = TrendingMoviesModuleConfigurator()
//        configurator.configureModuleForViewInput(viewInput: trendingmoviesViewController)
//    }
    
    func viewController(collection: MovieCollection) -> UIViewController {
        let storyboard = UIStoryboard(name: "TrendingMovies", bundle: Bundle.main)
        let vc = storyboard.instantiateViewController(withIdentifier: "TrendingMoviesViewController") as! TrendingMoviesViewController
        let configurator = TrendingMoviesModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: vc, collection: collection)
        
        return vc
    }

}
