//
//  TrendingMoviesTrendingMoviesViewController.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit

class TrendingMoviesViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var output: TrendingMoviesViewOutput!
    private var pageNumber: Int = 1
    private var isLoading: Bool = false
    

    // MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        output.viewIsReady()
        title = "Trending Movies"
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(UINib(nibName: MovieCell.identifier, bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: MovieCell.identifier)
        tableView.showsVerticalScrollIndicator = false
        tableView.rowHeight = UITableView.automaticDimension
        output.fetchMovies(pageNumber)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    var movies: [MovieEntity.Movie] = [] {
           didSet {
            isLoading = false
            tableView.reloadData()
        }
    }
}

// MARK: TrendingMoviesViewInput
extension TrendingMoviesViewController: TrendingMoviesViewInput {
    
    func setNavigationTitle(_ title: String) {
        self.title = title
    }
    
    func setMovies(_ movies: [MovieEntity.Movie]) {
        self.movies = movies
    }
    
    func setupInitialState() {
    }
    
    func setTrendingMovies(_ movies: [MovieEntity.Movie]) {
        self.movies += movies
    }
    func getController() -> UIViewController {
        return self
    }
}


extension TrendingMoviesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identifier, for: indexPath) as! MovieCell
        
        cell.movie = movies[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movieid = movies[indexPath.row].id
        output?.openMovieDetails(with: movieid)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        let deltaOffset = maximumOffset - currentOffset
        
        if deltaOffset <= 10 && currentOffset > 200 && !isLoading {
            isLoading = true
            pageNumber += 1
            output?.fetchMovies(pageNumber)
        }
        
    }
}

