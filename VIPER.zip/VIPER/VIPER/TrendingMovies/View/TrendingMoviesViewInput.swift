//
//  TrendingMoviesTrendingMoviesViewInput.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//
import UIKit

protocol TrendingMoviesViewInput: class {

    /**
        @author Maksat Sabitbek
        Setup initial state of the view
    */

    func setupInitialState()
    func setNavigationTitle(_ title: String)
    func setTrendingMovies(_ movies: [MovieEntity.Movie])
    func getController() -> UIViewController
}
