//
//  MovieCell.swift
//  MovieAppAss2
//
//  Created by Мас on 22.04.2021.
//

import UIKit
import Kingfisher

class MovieCell: UITableViewCell {
    
    public static let identifier: String = "MovieCell"

    @IBOutlet private weak var posterImageView: UIImageView!
    @IBOutlet private weak var ratingLabel: UILabel!
    @IBOutlet private weak var containerRatingView: UIView!
    @IBOutlet private weak var movieTitleLabel: UILabel!
    @IBOutlet private weak var releaseDateLabel: UILabel!
    
    public var movie: MovieEntity.Movie? {
        didSet{
            if let movie = movie {
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w400/" + (movie.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                ratingLabel.text = "\(movie.rating)"
                movieTitleLabel.text = movie.title
                releaseDateLabel.text = movie.releaseDate
                
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        selectionStyle = .none
        containerRatingView.layer.cornerRadius = 20
        containerRatingView.layer.masksToBounds = true
        posterImageView.layer.cornerRadius = 12
        posterImageView.layer.masksToBounds = true
   
    }
}

extension MovieCell {
    public func setMovie(_ movie: MovieEntity.Movie) {
        self.movie = movie
    }
}


private extension MovieCell {
    func configureLayout() {
        configureRatingContainerView()
        configurePosterImageView()
    }
    
    func configurePosterImageView() {
        posterImageView.layer.cornerRadius = 12
    }
    
    func configureRatingContainerView() {
        ratingLabel.layer.cornerRadius = ratingLabel.layer.bounds.height / 2
//        ratingContainerView.backgroundColor =  getColorByReting(movie?.rating ?? 0)
        
        func getColorByReting(_ rating: Double) -> UIColor {
            switch rating {
            case 0..<5:
                return UIColor.systemRed
            case 5..<7:
                return UIColor.systemYellow
            case 7...10:
                return UIColor.systemGreen
            default:
                return UIColor.systemGray4
            }
        }
    }
    
    
}

