//
//  TrendingMoviesTrendingMoviesPresenter.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

class TrendingMoviesPresenter: TrendingMoviesModuleInput {

    weak var view: TrendingMoviesViewInput!
    var interactor: TrendingMoviesInteractorInput!
    var router: TrendingMoviesRouterInput!
    let movieCollection: MovieCollection

    init(colection: MovieCollection) {
        self.movieCollection = colection
    }
}

extension TrendingMoviesPresenter: TrendingMoviesModuleInput {

}

extension TrendingMoviesPresenter: TrendingMoviesViewOutput {
    func openMovieDetails(with id: Int) {
        router.openMovieDetails(with: id, controller: self.view.getController())
    }
    
    func fetchMovies(_ pageNumber: Int) {
        interactor?.getTrendingMovies(pageNumber, collection: movieCollection)
    }
    

    func viewIsReady() {

    }
}

extension TrendingMoviesPresenter: TrendingMoviesInteractorOutput {
    
    func setMovies(_ movies: [MovieEntity.Movie]) {
        view.setTrendingMovies(movies)
        view.setNavigationTitle(movieCollection.rawValue)
    }
}
