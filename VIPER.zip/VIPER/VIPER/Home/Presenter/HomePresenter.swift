//
//  HomeHomePresenter.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

class HomePresenter {

    weak var view: HomeViewInput!
    var interactor: HomeInteractorInput!
    var router: HomeRouterInput!

}

// MARK: HomeModuleInput
extension HomePresenter: HomeModuleInput {

}

// MARK: HomeViewOutput
extension HomePresenter: HomeViewOutput {
    func openMovies(collection: MovieCollection) {
        router.openMovies(collection: collection, controller: view.getController())
    }
    
    func openMovieDetails(with id: Int) {
        router.openMovieDetails(with: id, controller: self.view.getController())
    }
    

    func viewIsReady() {
        interactor.fetchTrendingMovies()
        interactor.fetchTodayMovies()
        interactor.fetchSoonMovies()
    }
}

// MARK: HomeInteractorOutput
extension HomePresenter: HomeInteractorOutput {
    func setTrendingMovies(_ movies: [MovieEntity.Movie]) {
        view.setTrendingMovies(movies)
    }
    
    func setSoonMovies(_ movies: [MovieEntity.Movie]) {
        view.setSoonMovies(movies)
    }
    
    func setTodayMovies(_ movies: [MovieEntity.Movie]) {
        view.setTodayMovies(movies)
    }
}
