//
//  HomeHomeRouter.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//
import UIKit
import Foundation
class HomeRouter {

}

extension HomeRouter: HomeRouterInput {
    func openMovies(collection: MovieCollection, controller: UIViewController) {
        let newController = TrendingMoviesModuleInitializer().viewController(collection: collection)
        controller.navigationController?.pushViewController(newController, animated: true)
    }
    
    func openMovieDetails(with id: Int, controller: UIViewController) {
        let newController = MovieDetailsModuleInitializer().viewController(with: id)
        controller.navigationController?.pushViewController(newController, animated: true)
    }
}
