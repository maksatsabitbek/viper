//
//  HomeHomeViewController.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    var output: HomeViewOutput!
    
    @IBOutlet weak var today: UICollectionView!
    @IBOutlet weak var soon: UICollectionView!
    @IBOutlet weak var trending: UICollectionView!
    
    var todayMovies: [MovieEntity.Movie] = [MovieEntity.Movie]() {
        didSet{
            today.reloadData()
        }
    }
    var soonMovies: [MovieEntity.Movie] = [MovieEntity.Movie]() {
        didSet{
            soon.reloadData()
        }
    }
    var trendingMovies: [MovieEntity.Movie] = [MovieEntity.Movie]() {
        didSet{
            trending.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureNavigationBar()
        output.viewIsReady()
        configureCollectionsView()
    }

    @IBAction func openAllToday(_ sender: Any) {
        output.openMovies(collection: MovieCollection.Today)
    }
    @IBAction func openAllSoon(_ sender: Any) {
        output.openMovies(collection: MovieCollection.Soon)
    }
    @IBAction func openAllTrending(_ sender: Any) {
        output.openMovies(collection: MovieCollection.Trending)
    }
    
}


extension HomeViewController: HomeViewInput {
    func getController() -> UIViewController {
        return self
    }
    
    func setTrendingMovies(_ movies: [MovieEntity.Movie]) {
        trendingMovies = movies
    }
    
    func setSoonMovies(_ movies: [MovieEntity.Movie]) {
        soonMovies = movies
    }
    
    func setTodayMovies(_ movies: [MovieEntity.Movie]) {
        todayMovies = movies
    }
    
    
    func setupInitialState() {
        
    }
    
}

// MARK: Private func
private extension HomeViewController {
    func configureCollectionsView() {
        today.delegate = self
        today.dataSource = self
        today.register(MovieCollectionViewCell.nib, forCellWithReuseIdentifier: MovieCollectionViewCell.idetifier)
        
        soon.delegate = self
        soon.dataSource = self
        soon.register(MovieCollectionViewCell.nib, forCellWithReuseIdentifier: MovieCollectionViewCell.idetifier)
        
        trending.delegate = self
        trending.dataSource = self
        trending.register(MovieCollectionViewCell.nib, forCellWithReuseIdentifier: MovieCollectionViewCell.idetifier)
    }
    
    func configureNavigationBar(){
        title = "Home"
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor(cgColor: CGColor(red: 0.000, green: 0.769, blue: 0.683, alpha: 1.0))]
        navigationController?.navigationBar.barTintColor = UIColor.black
    }
}

// MARK: UICollectionViewDelegate
extension HomeViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch collectionView {
        case today:
            output.openMovieDetails(with: todayMovies[indexPath.item].id)
        case soon:
            output.openMovieDetails(with: soonMovies[indexPath.item].id)
        case trending:
            output.openMovieDetails(with: trendingMovies[indexPath.item].id)
        default:
            break
        }
    }
}

// MARK: UICollectionViewDataSource
extension HomeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView {
        case today:
            return todayMovies.count
        case soon:
            return soonMovies.count
        case trending:
            return trendingMovies.count
        default:
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch collectionView {
        case today:
            let cell = today.dequeueReusableCell(withReuseIdentifier: MovieCollectionViewCell.idetifier, for: indexPath) as! MovieCollectionViewCell
            
            cell.setMovie(todayMovies[indexPath.item])
            
            return cell
            
        case soon:
            let cell = soon.dequeueReusableCell(withReuseIdentifier: MovieCollectionViewCell.idetifier, for: indexPath) as! MovieCollectionViewCell
            
            cell.setMovie(soonMovies[indexPath.item])
            
            return cell
            
        case trending:
            let cell = trending.dequeueReusableCell(withReuseIdentifier: MovieCollectionViewCell.idetifier, for: indexPath) as! MovieCollectionViewCell
            
            cell.setMovie(trendingMovies[indexPath.item])
            
            return cell
            
        default:
            return UICollectionViewCell()
            
        }
        
        
        
    }
}
