//
//  HomeHomeInteractorInput.swift
//  VIPER
//
//  Created by Maksat Sabitbek on 04/06/2021.
//  Copyright © 2021 iOS Dev. All rights reserved.
//

import Foundation

protocol HomeInteractorInput {
    func fetchTrendingMovies()
    func fetchSoonMovies()
    func fetchTodayMovies()
}
