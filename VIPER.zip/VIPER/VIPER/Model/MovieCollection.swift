//
//  MovieCollection.swift
//  VIPER
//
//  Created by Мас on 04.06.2021.
//

import Foundation
enum MovieCollection: String {
    
    case Trending
    case Soon
    case Today
}
