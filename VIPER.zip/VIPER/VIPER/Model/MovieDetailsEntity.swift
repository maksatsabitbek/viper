//
//  MovieDetailsEntity.swift
//  VIPER
//
//  Created by Мас on 02.06.2021.
//

import Foundation

struct MovieDetailsEntity: Decodable {
    let description: String
    let poster: String?
    let title: String
    let releaseDate: String
    let rating: Double
    
    enum CodingKeys: String, CodingKey {
        case description = "overview"
        case poster = "poster_path"
        case title = "title"
        case releaseDate = "release_date"
        case rating = "vote_average"
    }
}
