//
//  GenreEntity.swift
//  VIPER
//
//  Created by Мас on 04.06.2021.
//

import Foundation
struct GenreEntity: Decodable {
    let genres: [Genre]
    
    struct Genre: Decodable {
        let id: Int
        let name: String
    }
    
}
